### Binary masks

GMmask.nii: Gray matter mask

subcortex_mask.nii: Subcortex mask including thalamus, hippocampus, amygdala, caudate, nucleus accumbens, putamen and globus pallidus 

subcortex_mask_part1: a binary mask comprising thalamus, hippocampus and amygdala.
