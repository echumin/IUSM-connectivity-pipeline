Source code from 
(https://github.com/Washington-University/HCPpipelines/tree/master/ICAFIX/scripts)
